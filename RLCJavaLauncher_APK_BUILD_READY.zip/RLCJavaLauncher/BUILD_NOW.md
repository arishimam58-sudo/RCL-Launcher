# Build APK RLC Java Launcher

## Cara paling mudah: GitHub Actions

1. Upload seluruh folder project ini ke repository GitHub.
2. Buka tab **Actions**.
3. Pilih **Build RLC Java Launcher APK**.
4. Jalankan **Run workflow**.
5. Setelah selesai, buka hasil run dan download artifact **RLCJavaLauncher-debug**.
6. Di dalam artifact ada `app-debug.apk`, yang bisa langsung di-install pada Android dengan mengizinkan pemasangan dari sumber tersebut.

Workflow sudah menyediakan Java 21, Android SDK 35, Build Tools 35.0.0, dan Gradle 8.9.

## Catatan penting

APK yang dibangun dari project ini adalah **RLC Java Launcher UI + installer/integrasi**. Engine Minecraft/Pojav belum dibenamkan ke APK ini; tombol Play masih menjembatani ke Pojav bila Pojav sudah terpasang.

Untuk menjadi satu APK mandiri yang berisi engine Java Minecraft, source engine Pojav/Amethyst perlu digabungkan ke modul Android dan dibangun bersama. Itu merupakan tahap integrasi berikutnya, bukan sesuatu yang dapat diklaim sudah terkandung di APK ini.
