# RLC Java Launcher — Current Status

Reference audit: 22/22 supplied screenshots inspected.

## Implemented in source
- Landscape-style launcher shell inspired by the supplied reference layout.
- Responsive vertical navigation rail.
- Home / Download Mod / Download Modpack / Download Resource Pack / Download World / Download Shader Pack / Settings.
- Settings subsections for Video, Controls, Game, Launcher, and Experimental.
- Search provider switch: Modrinth / CurseForge.
- Minecraft version, loader, category and sort filters in the UI.
- Modrinth search facets and version-aware latest-file lookup.
- CurseForge search, latest-file lookup, and official API-key flow.
- Local import and remote install routing for common Minecraft content.
- Modrinth `.mrpack` and CurseForge modpack archive installation paths.
- World ZIP auto-detection when `level.dat` exists.
- Shader/resource-pack ZIP detection.
- JSON/YAML/control profile import path.
- Pojav package detection and launch bridge.

## Build verification note
The current execution environment does not contain an Android SDK or the Gradle wrapper JAR/distribution, so an APK build could not be executed here. Kotlin source was structurally checked and no parser-level syntax errors were found.

## Next integration layer
For a true single-APK replacement rather than a companion launcher, merge the open-source Pojav/Amethyst engine modules and runtimes into this application, then route the selected profile/instance directly to the embedded game launcher instead of opening the external Pojav package.
