# RLC Java Launcher

A clean Android launcher shell for Minecraft Java Edition, designed from the supplied Zalith-style UI references while using original branding and UI assets.

## Highlights

- Launcher-style vertical navigation and translucent panels.
- Download pages for mods, modpacks, resource packs, worlds, and shaders.
- Modrinth and CurseForge search integration.
- Mojang Java Edition version manifest integration.
- Local import for JAR / ZIP / MRPACK / JSON / YAML.
- Remote installation routing into the selected Minecraft directory.
- Settings pages for video, controls, game/runtime, launcher, and experimental options.
- Pojav detection/launch bridge for the existing installed Java engine.

## Project

- Package: `com.rlcjava.launcher`
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
- Kotlin + Jetpack Compose + Material 3
- Java/Kotlin compatibility: 17

## Android Studio

Open the `RLCJavaLauncher` folder in Android Studio and let Gradle sync dependencies. The environment used to prepare this source package did not contain an Android SDK, so no APK artifact is claimed in this package.

## Reference audit

See `docs/REFERENCE_AUDIT.md` for the 22-screenshot mapping and the design rules extracted from the supplied archive.

## Important integration boundary

This project is the new launcher UI and content-management layer. It does not bundle the full Pojav/Amethyst game engine yet. The current bridge detects a separately installed Pojav package and opens it.

For a single self-contained APK, the next step is to merge the open-source Pojav/Amethyst Android engine and mobile Java runtimes into this project.
