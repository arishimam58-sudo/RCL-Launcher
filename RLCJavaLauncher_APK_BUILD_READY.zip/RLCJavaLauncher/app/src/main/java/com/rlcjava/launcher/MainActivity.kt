package com.rlcjava.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rlcjava.launcher.core.LauncherStore
import coil.compose.AsyncImage
import com.rlcjava.launcher.install.ContentInstaller
import com.rlcjava.launcher.network.CurseForgeClient
import com.rlcjava.launcher.network.MinecraftManifestClient
import com.rlcjava.launcher.network.ModrinthClient
import com.rlcjava.launcher.pojav.PojavBridge
import kotlinx.coroutines.launch

private val Bg = Color(0xFF080A10)
private val Panel = Color(0xB91A202B)
private val PanelStrong = Color(0xE01B202A)
private val Line = Color(0x668A91A6)
private val TextMain = Color(0xFFF5F7FB)
private val TextMuted = Color(0xFFADB5C5)
private val Accent = Color(0xFF69E7D1)
private val Accent2 = Color(0xFF9C8CFF)
private val Warm = Color(0xFFFFB78A)

private enum class MainPage(val title: String, val icon: ImageVector, val kind: String? = null) {
    HOME("Home", Icons.Default.Home),
    MOD("Download Mod", Icons.Default.Extension, "mod"),
    MODPACK("Download Modpack", Icons.Default.Inventory2, "modpack"),
    RESOURCE("Download Resource Pack", Icons.Default.Folder, "resourcepack"),
    WORLD("Download World", Icons.Default.Public, "world"),
    SHADER("Download Shader Pack", Icons.Default.Lightbulb, "shader"),
    SETTINGS("Settings", Icons.Default.Settings)
}

private enum class Provider { MODRINTH, CURSEFORGE }

private enum class SettingSection(val title: String, val icon: ImageVector) {
    VIDEO("Video Settings", Icons.Default.Tune),
    CONTROLS("Control Settings", Icons.Default.SportsEsports),
    GAME("Game Settings", Icons.Default.VideogameAsset),
    LAUNCHER("Launcher Settings", Icons.Default.Launch),
    EXPERIMENTAL("Experimental Settings", Icons.Default.Science)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RlcTheme { LauncherApp() } }
    }
}

@Composable
private fun RlcTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = PanelStrong,
            primary = Accent,
            secondary = Accent2,
            onPrimary = Color.Black,
            onBackground = TextMain,
            onSurface = TextMain,
            outline = Line
        ),
        typography = Typography(
            bodyLarge = LocalTextStyle.current,
            labelLarge = LocalTextStyle.current.copy(fontWeight = FontWeight.SemiBold)
        ),
        content = content
    )
}

@Composable
private fun LauncherApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { LauncherStore(context) }
    val bridge = remember { PojavBridge(context) }

    var page by remember { mutableStateOf(MainPage.HOME) }
    var setting by remember { mutableStateOf(SettingSection.VIDEO) }
    var toast by remember { mutableStateOf<String?>(null) }

    var query by remember { mutableStateOf("") }
    var provider by remember { mutableStateOf(Provider.MODRINTH) }
    var mcVersion by remember { mutableStateOf("1.21.11") }
    var loader by remember { mutableStateOf("Fabric") }
    var sort by remember { mutableStateOf("Relevance") }
    var category by remember { mutableStateOf("All") }
    var modrinthHits by remember { mutableStateOf<List<ModrinthClient.Hit>>(emptyList()) }
    var curseHits by remember { mutableStateOf<List<CurseForgeClient.Mod>>(emptyList()) }
    var versions by remember { mutableStateOf<List<MinecraftManifestClient.Version>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }

    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                store.setGameRoot(uri.toString())
                toast = "Folder Minecraft tersimpan."
            }.onFailure { toast = it.message }
        }
    }

    val localPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                runCatching {
                    ContentInstaller.installAny(context, uri, store.gameRootUri(), store.curseForgeKey())
                }.onSuccess { toast = "Berhasil memasang $it" }
                    .onFailure { toast = "Gagal: ${it.message}" }
                busy = false
            }
        }
    }

    fun doSearch() {
        if (query.isBlank()) {
            toast = "Tulis nama mod, modpack, shader, world, atau resource pack."
            return
        }
        scope.launch {
            busy = true
            if (provider == Provider.MODRINTH) {
                runCatching {
                    ModrinthClient.search(
                        query = query,
                        limit = 40,
                        projectType = page.kind,
                        gameVersion = mcVersion.takeIf { it.isNotBlank() },
                        loader = loader.lowercase().takeIf { page.kind == "mod" || page.kind == "modpack" },
                        category = category.takeIf { it != "All" }?.lowercase(),
                        sort = sort
                    )
                }.onSuccess {
                    modrinthHits = it
                    toast = "Modrinth: ${it.size} hasil."
                }.onFailure { toast = "Modrinth: ${it.message}" }
            } else {
                runCatching { CurseForgeClient(store.curseForgeKey()).search(query, 40) }
                    .onSuccess {
                        curseHits = it
                        toast = "CurseForge: ${it.size} hasil."
                    }.onFailure { toast = "CurseForge: ${it.message}" }
            }
            busy = false
        }
    }

    fun refreshVersions() {
        scope.launch {
            busy = true
            runCatching { MinecraftManifestClient.fetch().versions.take(60) }
                .onSuccess { versions = it; toast = "Manifest Mojang diperbarui." }
                .onFailure { toast = "Gagal memuat versi: ${it.message}" }
            busy = false
        }
    }

    Box(Modifier.fillMaxSize()) {
        ScenicBackdrop()
        Row(Modifier.fillMaxSize()) {
            if (page != MainPage.SETTINGS) {
                MainRail(page, onSelect = { page = it })
            } else {
                SettingsRail(setting, onSelect = { setting = it }, onBack = { page = MainPage.HOME })
            }

            Column(Modifier.fillMaxSize()) {
                LauncherHeader(
                    title = if (page == MainPage.SETTINGS) "Settings" else page.title,
                    gameRootSet = store.gameRootUri() != null,
                    onChooseRoot = { treePicker.launch(null) },
                    onHome = { page = MainPage.HOME },
                    onOpenInstall = { localPicker.launch(arrayOf("*/*")) }
                )

                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when {
                        page == MainPage.HOME -> HomeScreen(
                            bridge = bridge,
                            installed = bridge.isInstalled(),
                            javaMode = store.javaMode(),
                            rootSet = store.gameRootUri() != null,
                            onPlay = { toast = bridge.launchPojav() },
                            onMods = { page = MainPage.MOD },
                            onImport = { localPicker.launch(arrayOf("*/*")) },
                            onChooseRoot = { treePicker.launch(null) },
                            onVersions = { refreshVersions() },
                            versionCount = versions.size
                        )
                        page == MainPage.SETTINGS -> SettingsScreen(setting, store, onJavaMode = { store.setJavaMode(it) }, onImportControls = { localPicker.launch(arrayOf("application/json", "application/x-yaml", "text/yaml", "*/*")) })
                        else -> ContentHubScreen(
                            page = page,
                            provider = provider,
                            query = query,
                            onQuery = { query = it },
                            mcVersion = mcVersion,
                            onMcVersion = { mcVersion = it },
                            loader = loader,
                            onLoader = { loader = it },
                            sort = sort,
                            onSort = { sort = it },
                            category = category,
                            onCategory = { category = it },
                            onProvider = { provider = it },
                            onSearch = ::doSearch,
                            modrinth = modrinthHits,
                            curseforge = curseHits,
                            rootUri = store.gameRootUri(),
                            curseForgeKey = store.curseForgeKey(),
                            busy = busy,
                            onInstallLocal = { localPicker.launch(arrayOf("*/*")) },
                            toast = { toast = it }
                        )
                    }
                }
            }
        }

        if (toast != null) {
            AssistChip(
                onClick = { toast = null },
                label = { Text(toast.orEmpty(), maxLines = 2, overflow = TextOverflow.Ellipsis) },
                modifier = Modifier.align(Alignment.BottomCenter).padding(18.dp),
                colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xE6252933))
            )
        }
    }
}

@Composable
private fun ScenicBackdrop() {
    Canvas(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1C2B3B), Color(0xFF111720), Color(0xFF07090D))))) {
        drawCircle(Color(0x55FFB16B), radius = size.minDimension * 0.28f, center = Offset(size.width * 0.78f, size.height * 0.18f))
        drawClouds(this)
        val mountain = Path().apply {
            moveTo(0f, size.height * .62f)
            lineTo(size.width * .15f, size.height * .42f)
            lineTo(size.width * .25f, size.height * .56f)
            lineTo(size.width * .40f, size.height * .33f)
            lineTo(size.width * .52f, size.height * .56f)
            lineTo(size.width * .69f, size.height * .38f)
            lineTo(size.width * .88f, size.height * .59f)
            lineTo(size.width, size.height * .44f)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(mountain, Brush.verticalGradient(listOf(Color(0x88303A47), Color(0xFF0A0D12))))
        drawForest(this)
        drawRect(Color(0x6604080D))
    }
}

private fun drawClouds(scope: DrawScope) {
    with(scope) {
        val cloud = Color(0x229BA8B7)
        repeat(7) { i ->
            val y = size.height * (0.12f + i * 0.045f)
            drawCircle(cloud, 48f + i * 9f, Offset(size.width * (0.08f + i * 0.13f), y))
            drawCircle(cloud, 74f + i * 5f, Offset(size.width * (0.13f + i * 0.13f), y + 7f))
        }
    }
}

private fun drawForest(scope: DrawScope) {
    with(scope) {
        val baseY = size.height * .73f
        for (i in 0..90) {
            val x = size.width * (i / 90f)
            val h = size.height * (0.04f + (i % 9) * 0.008f)
            val p = Path().apply {
                moveTo(x, baseY)
                lineTo(x + 10f, baseY - h)
                lineTo(x + 20f, baseY)
                close()
            }
            drawPath(p, Color(0xDD0A1214))
        }
    }
}

@Composable
private fun MainRail(selected: MainPage, onSelect: (MainPage) -> Unit) {
    Surface(
        modifier = Modifier.width(92.dp).fillMaxHeight(),
        color = Color(0x9A0B0D12),
        border = BorderStroke(1.dp, Color(0x332F3542))
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(vertical = 14.dp, horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            item {
                Column(Modifier.fillMaxWidth().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("RLC", color = Accent, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Text("JAVA", color = TextMuted, fontSize = 8.sp, letterSpacing = 2.sp)
                }
            }
            items(MainPage.values().toList().filter { it != MainPage.SETTINGS }) { item ->
                RailItem(item.title, item.icon, selected == item) { onSelect(item) }
            }
            item { Spacer(Modifier.height(6.dp)); HorizontalDivider(color = Line) }
            item { RailItem(MainPage.SETTINGS.title, MainPage.SETTINGS.icon, selected == MainPage.SETTINGS) { onSelect(MainPage.SETTINGS) } }
        }
    }
}

@Composable
private fun SettingsRail(selected: SettingSection, onSelect: (SettingSection) -> Unit, onBack: () -> Unit) {
    Surface(Modifier.width(154.dp).fillMaxHeight(), color = Color(0x9A0B0D12), border = BorderStroke(1.dp, Color(0x332F3542))) {
        LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(6.dp)); Text("Home")
                }
            }
            item { Text("Settings", Modifier.padding(horizontal = 8.dp), fontWeight = FontWeight.Bold, color = Accent) }
            items(SettingSection.values().toList()) { s -> RailItem(s.title, s.icon, selected == s) { onSelect(s) } }
        }
    }
}

@Composable
private fun RailItem(title: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) Color(0x443C495B) else Color.Transparent
    val tint = if (selected) Accent else TextMuted
    Surface(onClick = onClick, color = bg, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(vertical = 9.dp, horizontal = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(23.dp))
            Spacer(Modifier.height(4.dp))
            Text(title.removePrefix("Download ").replace(" Settings", ""), color = tint, fontSize = 8.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun LauncherHeader(title: String, gameRootSet: Boolean, onChooseRoot: () -> Unit, onHome: () -> Unit, onOpenInstall: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(if (gameRootSet) "Minecraft directory terhubung" else "Folder Minecraft belum dipilih", color = TextMuted, fontSize = 10.sp)
        }
        IconButton(onClick = onOpenInstall) { Icon(Icons.Default.FileOpen, "Import", tint = TextMuted) }
        IconButton(onClick = onHome) { Icon(Icons.Default.Home, "Home", tint = TextMuted) }
        TextButton(onClick = onChooseRoot) {
            Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text(if (gameRootSet) "Folder" else "Pilih folder")
        }
    }
}

@Composable
private fun HomeScreen(
    bridge: PojavBridge,
    installed: Boolean,
    javaMode: String,
    rootSet: Boolean,
    onPlay: () -> Unit,
    onMods: () -> Unit,
    onImport: () -> Unit,
    onChooseRoot: () -> Unit,
    onVersions: () -> Unit,
    versionCount: Int
) {
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                Surface(
                    modifier = Modifier.weight(1.35f).heightIn(min = 205.dp),
                    color = Panel,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, Color(0x55474F60))
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Minecraft Java", fontSize = 27.sp, fontWeight = FontWeight.Black)
                                Text("RLC Launcher", color = Accent, fontSize = 12.sp, letterSpacing = 1.7.sp)
                            }
                            Surface(color = Color(0x33FFFFFF), shape = RoundedCornerShape(20.dp)) {
                                Text(if (installed) "Pojav terdeteksi" else "Pojav belum terpasang", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = if (installed) Accent else Warm, fontSize = 10.sp)
                            }
                        }
                        Column {
                            Text("Java runtime", color = TextMuted, fontSize = 11.sp)
                            Text(javaMode, fontWeight = FontWeight.Bold)
                        }
                        Button(onClick = onPlay, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(7.dp)); Text("Launch Game", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Surface(modifier = Modifier.weight(.8f).heightIn(min = 205.dp), color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Color(0x55474F60))) {
                    Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Quick actions", fontWeight = FontWeight.Bold)
                        HomeAction("Manage Mods", "Modrinth + CurseForge", Icons.Default.Extension, onMods)
                        HomeAction("Import Content", "JAR / ZIP / MRPACK / World", Icons.Default.FileOpen, onImport)
                        HomeAction("Minecraft Folder", if (rootSet) "Connected" else "Choose directory", Icons.Default.FolderOpen, onChooseRoot)
                        HomeAction("Minecraft Versions", "$versionCount cached", Icons.Default.CloudDownload, onVersions)
                    }
                }
            }
        }
        item {
            Text("Launcher capabilities", fontWeight = FontWeight.SemiBold, color = TextMuted, fontSize = 12.sp)
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Capability("Mods", "Fabric / Forge / NeoForge", Icons.Default.Extension)
                Capability("Shaders", "shaderpacks/", Icons.Default.Lightbulb)
                Capability("Worlds", "saves/ ZIP import", Icons.Default.Public)
                Capability("Controls", "JSON / YAML / backup", Icons.Default.SportsEsports)
                Capability("Java", "8 / 17 / 21 selector", Icons.Default.Memory)
            }
        }
    }
}

@Composable
private fun HomeAction(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Surface(onClick = onClick, color = Color(0x2AFFFFFF), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text(subtitle, color = TextMuted, fontSize = 9.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = TextMuted, modifier = Modifier.size(17.dp))
        }
    }
}

@Composable
private fun Capability(title: String, subtitle: String, icon: ImageVector) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Color(0x4439414E))) {
        Column(Modifier.width(180.dp).padding(14.dp)) {
            Icon(icon, null, tint = Accent2, modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = TextMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ContentHubScreen(
    page: MainPage,
    provider: Provider,
    query: String,
    onQuery: (String) -> Unit,
    mcVersion: String,
    onMcVersion: (String) -> Unit,
    loader: String,
    onLoader: (String) -> Unit,
    sort: String,
    onSort: (String) -> Unit,
    category: String,
    onCategory: (String) -> Unit,
    onProvider: (Provider) -> Unit,
    onSearch: () -> Unit,
    modrinth: List<ModrinthClient.Hit>,
    curseforge: List<CurseForgeClient.Mod>,
    rootUri: Uri?,
    curseForgeKey: String,
    busy: Boolean,
    onInstallLocal: () -> Unit,
    toast: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    Row(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 18.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(page.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Cari, cek kompatibilitas, lalu pasang langsung ke directory Minecraft.", color = TextMuted, fontSize = 10.sp)
                    }
                    if (busy) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                }
            }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = onQuery,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Search name", color = TextMuted) },
                    trailingIcon = { IconButton(onClick = onSearch) { Icon(Icons.Default.Search, null) } },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0x44131A25),
                        unfocusedContainerColor = Color(0x33131A25),
                        focusedBorderColor = Accent,
                        unfocusedBorderColor = Line
                    )
                )
            }
            when (provider) {
                Provider.MODRINTH -> {
                    item { ProviderBadge("Modrinth", Accent) }
                    if (modrinth.isEmpty()) item { EmptyResults("Belum ada hasil. Gunakan Search di kanan atau tekan ikon 🔍.") }
                    items(modrinth) { hit ->
                        ContentResultCard(
                            title = hit.title,
                            description = hit.description,
                            meta = "${hit.projectType} • ${hit.downloads} downloads",
                            source = "Modrinth",
                            iconUrl = hit.iconUrl,
                            onInstall = {
                                if (rootUri == null) {
                                    toast("Pilih folder Minecraft dahulu.")
                                } else {
                                    scope.launch {
                                        runCatching {
                                            val file = ModrinthClient.latestFile(hit.projectId, mcVersion, loader.takeIf { page.kind == "mod" } ?: "")
                                                ?: error("Tidak ada file kompatibel untuk $mcVersion.")
                                            ContentInstaller.installRemote(context, file.url, rootUri, file.fileName, page.kind ?: "modpack", curseForgeKey)
                                        }.onSuccess { toast("Terpasang: $it") }
                                            .onFailure { toast("Install gagal: ${it.message}") }
                                    }
                                }
                            }
                        )
                    }
                }
                Provider.CURSEFORGE -> {
                    item { ProviderBadge("CurseForge", Warm) }
                    if (curseforge.isEmpty()) item { EmptyResults("Belum ada hasil. Masukkan CurseForge API key di Settings.") }
                    items(curseforge) { hit ->
                        ContentResultCard(
                            title = hit.name,
                            description = hit.summary,
                            meta = "CurseForge • #${hit.id}",
                            source = "CurseForge",
                            iconUrl = null,
                            onInstall = {
                                if (rootUri == null) toast("Pilih folder Minecraft dahulu.")
                                else if (curseForgeKey.isBlank()) toast("Isi CurseForge API key di Settings.")
                                else {
                                    scope.launch {
                                        runCatching {
                                            val loaderType = if (page.kind == "mod") 4 else null
                                            val file = CurseForgeClient(curseForgeKey).latestFile(hit.id, mcVersion, loaderType)
                                                ?: error("Tidak ada file kompatibel untuk $mcVersion.")
                                            val url = file.downloadUrl ?: CurseForgeClient(curseForgeKey).downloadUrl(hit.id, file.id)
                                            ContentInstaller.installRemote(context, url, rootUri, file.fileName, page.kind ?: "mod", curseForgeKey)
                                        }.onSuccess { toast("Terpasang: $it") }
                                            .onFailure { toast("Install gagal: ${it.message}") }
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }

        FilterPanel(
            provider = provider,
            onProvider = onProvider,
            mcVersion = mcVersion,
            onMcVersion = onMcVersion,
            loader = loader,
            onLoader = onLoader,
            sort = sort,
            onSort = onSort,
            category = category,
            onCategory = onCategory,
            onSearch = onSearch,
            onInstallLocal = onInstallLocal,
            page = page
        )
    }
}

@Composable
private fun FilterPanel(
    provider: Provider,
    onProvider: (Provider) -> Unit,
    mcVersion: String,
    onMcVersion: (String) -> Unit,
    loader: String,
    onLoader: (String) -> Unit,
    sort: String,
    onSort: (String) -> Unit,
    category: String,
    onCategory: (String) -> Unit,
    onSearch: () -> Unit,
    onInstallLocal: () -> Unit,
    page: MainPage
) {
    Surface(
        modifier = Modifier.widthIn(min = 255.dp, max = 340.dp).fillMaxHeight(),
        color = Panel,
        shape = RoundedCornerShape(15.dp),
        border = BorderStroke(1.dp, Color(0x55474F60))
    ) {
        LazyColumn(contentPadding = PaddingValues(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                SegmentedProvider(provider, onProvider)
            }
            item { PanelLabel("Search platform") }
            item { CompactField("Minecraft", mcVersion, onMcVersion) }
            item { PanelLabel("Sort by") }
            item { CompactField("Sort", sort, onSort, listOf("Relevance", "Downloads", "Updated")) }
            item { PanelLabel("Category filter") }
            item { CompactField("Category", category, onCategory, listOf("All", "Adventure", "Optimization", "Library", "Vanilla+")) }
            item { PanelLabel("Mod loader") }
            item { CompactField("Loader", loader, onLoader, listOf("Fabric", "Forge", "NeoForge", "Quilt", "All")) }
            item {
                Button(onClick = onSearch, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)) {
                    Icon(Icons.Default.Search, null); Spacer(Modifier.width(6.dp)); Text("Search", fontWeight = FontWeight.Bold)
                }
            }
            item {
                OutlinedButton(onClick = onInstallLocal, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)) {
                    Icon(Icons.Default.FileOpen, null); Spacer(Modifier.width(6.dp)); Text("Install from local")
                }
            }
            item { HorizontalDivider(color = Line) }
            item { Text("Target", color = TextMuted, fontSize = 9.sp) }
            item { Text("${page.title} • $mcVersion", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
private fun SegmentedProvider(provider: Provider, onProvider: (Provider) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0x4411161D), RoundedCornerShape(10.dp)).padding(3.dp)) {
        ProviderButton("Modrinth", provider == Provider.MODRINTH) { onProvider(Provider.MODRINTH) }
        ProviderButton("CurseForge", provider == Provider.CURSEFORGE) { onProvider(Provider.CURSEFORGE) }
    }
}

@Composable
private fun ProviderButton(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, color = if (selected) Color(0x445D7682) else Color.Transparent, shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f)) {
        Box(Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) { Text(text, fontSize = 10.sp, color = if (selected) Accent else TextMuted, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
private fun CompactField(label: String, value: String, onChange: (String) -> Unit, options: List<String>? = null) {
    if (options == null) {
        OutlinedTextField(value, onChange, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text(label, fontSize = 9.sp) }, textStyle = LocalTextStyle.current.copy(fontSize = 11.sp))
    } else {
        var open by remember(value, label) { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(9.dp)) {
                Text(value, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Start, fontSize = 10.sp)
                Icon(Icons.Default.ExpandMore, null, modifier = Modifier.size(18.dp))
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); open = false }) }
            }
        }
    }
}

@Composable
private fun ContentResultCard(title: String, description: String, meta: String, source: String, iconUrl: String?, onInstall: () -> Unit) {
    Surface(color = Color(0xB7171C24), shape = RoundedCornerShape(11.dp), border = BorderStroke(1.dp, Color(0x4439404C))) {
        Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(Modifier.size(48.dp), shape = RoundedCornerShape(8.dp), color = Color(0x334E5D6B)) {
                Box(contentAlignment = Alignment.Center) {
                    if (iconUrl.isNullOrBlank()) {
                        Icon(Icons.Default.Extension, null, tint = Accent2, modifier = Modifier.size(24.dp))
                    } else {
                        AsyncImage(
                            model = iconUrl,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize().padding(5.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(description, color = TextMuted, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(3.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(meta, color = Accent, fontSize = 8.sp)
                    Text(source, color = TextMuted, fontSize = 8.sp)
                }
            }
            OutlinedButton(onClick = onInstall, shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(horizontal = 11.dp, vertical = 6.dp)) {
                Text("Install", fontSize = 9.sp)
            }
        }
    }
}

@Composable private fun ProviderBadge(text: String, tint: Color) { Text(text, color = tint, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
@Composable private fun EmptyResults(text: String) { Surface(color = Color(0x331A2029), shape = RoundedCornerShape(10.dp)) { Text(text, Modifier.padding(14.dp), color = TextMuted, fontSize = 10.sp) } }
@Composable private fun PanelLabel(text: String) { Text(text, color = Accent, fontSize = 9.sp, fontWeight = FontWeight.SemiBold) }

@Composable
private fun SettingsScreen(section: SettingSection, store: LauncherStore, onJavaMode: (String) -> Unit, onImportControls: () -> Unit) {
    var javaMode by remember { mutableStateOf(store.javaMode()) }
    LazyColumn(contentPadding = PaddingValues(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(section.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Pengaturan launcher disusun mengikuti pola panel + slider + toggle pada referensi.", color = TextMuted, fontSize = 10.sp)
        }
        when (section) {
            SettingSection.VIDEO -> {
                item { SettingCard("Video Settings") {
                    ToggleSetting("Fullscreen Mode", true)
                    ToggleSetting("Fullscreen Mode (Non-Game)", true)
                    SliderSetting("Resolution Scaling", 0.72f, "1128 × 504 • 70%")
                    ToggleSetting("Enable Sustained Performance Mode", true)
                    ToggleSetting("Alternative Surface Rendering", false)
                    ToggleSetting("Allow V-Sync with Zink", false)
                    ToggleSetting("Use System Vulkan Driver", true)
                } }
                item { SettingCard("Renderer") {
                    InfoSetting("Renderer", "MobileGL / Zink / Vulkan")
                    InfoSetting("Local Renderer Import", "Import renderer plugin jika dibutuhkan")
                } }
            }
            SettingSection.CONTROLS -> {
                item { SettingCard("Control Settings") {
                    ToggleSetting("Disable Gestures", false)
                    ToggleSetting("Disable Double Tap to Swap Items", true)
                    SliderSetting("Long Press Trigger Delay", 0.42f, "300 ms")
                    SliderSetting("Control Layout Scaling", 1f, "100%")
                    ToggleSetting("Use All Caps in Button Labels", true)
                    SliderSetting("Virtual Mouse Speed", 1f, "100%")
                    ToggleSetting("Show Virtual Mouse by Default on Game Start", false)
                    ToggleSetting("Gyro Control", false)
                } }
                item { SettingCard("Control layout") {
                    InfoSetting("Reset controller buttons", "Restore default touch controls")
                    Button(onClick = onImportControls, modifier = Modifier.fillMaxWidth()) { Text("Import control JSON / YAML") }
                } }
            }
            SettingSection.GAME -> {
                item { SettingCard("Runtime") {
                    InfoSetting("Runtime environment", javaMode)
                    JavaModeSetting(javaMode) {
                        javaMode = it
                        onJavaMode(it)
                    }
                    SliderSetting("Memory Allocation", 0.58f, "5677 MB")
                    ToggleSetting("Enable Sandbox Security Manager", true)
                    InfoSetting("JVM startup arguments", "Custom JVM arguments per instance")
                } }
                item { SettingCard("Game Menu") {
                    ToggleSetting("Real-time Memory Info Display", false)
                    ToggleSetting("Show real-time FPS", true)
                    InfoSetting("Memory Info Prefix", "%t")
                    SliderSetting("Information Refresh Rate", 0.60f, "5000 ms")
                    SliderSetting("Floating Window Opacity", 1f, "100%")
                } }
            }
            SettingSection.LAUNCHER -> {
                item { SettingCard("Downloads") {
                    ToggleSetting("Check Libraries After Download", true)
                    ToggleSetting("Game Version List Check", true)
                    ToggleSetting("Cache Resource Images", true)
                    ToggleSetting("Resource File Name Prefix", true)
                    SliderSetting("Max Download Threads", 0.62f, "64")
                } }
                item { SettingCard("Personalization") {
                    InfoSetting("Launcher Theme", "Dark Mode")
                    ToggleSetting("Enable Animations", true)
                    SliderSetting("Animation Speed", 0.32f, "600 ms")
                    SliderSetting("Page Opacity", 1f, "100%")
                    ToggleSetting("Open Launcher When Launching Game", false)
                    ToggleSetting("Quit Launcher", true)
                    InfoSetting("Clear Cache", "Remove app cache safely")
                } }
            }
            SettingSection.EXPERIMENTAL -> {
                item { SettingCard("Experimental Patches") {
                    ToggleSetting("Enable Shader Output", false)
                    ToggleSetting("Force Renderer to Run on Big Core", true)
                } }
                item { SettingCard("External Support") {
                    SliderSetting("TouchControl Mod Vibration Duration", 0.18f, "100 ms")
                    InfoSetting("Advanced profile", "JSON/YAML launcher configuration")
                } }
            }
        }
    }
}

@Composable
private fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(15.dp), border = BorderStroke(1.dp, Color(0x55474F60))) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
private fun InfoSetting(title: String, value: String) {
    Column {
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
        Text(value, color = TextMuted, fontSize = 9.sp)
    }
}

@Composable
private fun ToggleSetting(title: String, checked: Boolean) {
    var state by remember(title) { mutableStateOf(checked) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontSize = 10.sp); Text("Enabled in current profile", color = TextMuted, fontSize = 8.sp) }
        Switch(checked = state, onCheckedChange = { state = it })
    }
}

@Composable
private fun SliderSetting(title: String, value: Float, trailing: String) {
    var state by remember(title) { mutableFloatStateOf(value) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 10.sp)
            Slider(value = state, onValueChange = { state = it }, modifier = Modifier.fillMaxWidth())
        }
        Text(trailing, color = TextMuted, fontSize = 9.sp, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun JavaModeSetting(current: String, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }) { Text("Runtime: $current") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            listOf("Auto", "Java 8", "Java 17", "Java 21").forEach { v -> DropdownMenuItem(text = { Text(v) }, onClick = { onChange(v); expanded = false }) }
        }
    }
}
