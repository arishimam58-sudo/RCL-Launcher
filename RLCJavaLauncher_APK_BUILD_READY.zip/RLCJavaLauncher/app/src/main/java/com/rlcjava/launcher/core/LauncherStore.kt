package com.rlcjava.launcher.core

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class LauncherStore(context: Context) {
    private val p = context.getSharedPreferences("rlc_launcher", Context.MODE_PRIVATE)
    private val gson = Gson()
    fun setGameRoot(uri: String) = p.edit().putString("game_root", uri).apply()
    fun gameRootUri(): Uri? = p.getString("game_root", null)?.let(Uri::parse)
    fun curseForgeKey(): String = p.getString("cf_key", "") ?: ""
    fun setCurseForgeKey(value: String) = p.edit().putString("cf_key", value).apply()
    fun setJavaMode(value: String) = p.edit().putString("java_mode", value).apply()
    fun javaMode(): String = p.getString("java_mode", "Auto") ?: "Auto"
    fun instances(): List<String> {
        val raw = p.getString("instances", "[]") ?: "[]"
        return runCatching { gson.fromJson<List<String>>(raw, object: TypeToken<List<String>>(){}.type) ?: emptyList() }.getOrDefault(emptyList())
    }
}
