package com.rlcjava.launcher.install

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

object ContentInstaller {
    suspend fun installAny(context: Context, source: Uri, rootUri: Uri?, curseForgeKey: String = ""): String {
        require(rootUri != null) { "Pilih folder .minecraft/Pojav terlebih dahulu." }
        val root = DocumentFile.fromTreeUri(context, rootUri) ?: error("Folder tidak tersedia")
        val name = DocumentFile.fromSingleUri(context, source)?.name ?: "import"
        val lower = name.lowercase()
        context.contentResolver.openInputStream(source)?.use { input ->
            return when {
                lower.endsWith(".jar") -> {
                    copyFile(context, input, root, "mods/$name")
                    "mods/$name"
                }
                lower.endsWith(".mrpack") -> {
                    ZipInstaller.installInput(context, input, name, root, curseForgeKey)
                    "modpack/$name"
                }
                lower.endsWith(".zip") -> {
                    when {
                        lower.contains("shader") -> { copyFile(context, input, root, "shaderpacks/$name"); "shaderpacks/$name" }
                        lower.contains("resource") -> { copyFile(context, input, root, "resourcepacks/$name"); "resourcepacks/$name" }
                        else -> { ZipInstaller.installInput(context, input, name, root, curseForgeKey); name }
                    }
                }
                lower.endsWith(".json") || lower.endsWith(".yml") || lower.endsWith(".yaml") || lower.endsWith(".control") -> {
                    copyFile(context, input, root, "control_profiles/$name")
                    "control_profiles/$name"
                }
                else -> error("Format belum didukung: $name")
            }
        } ?: error("Tidak bisa membaca file")
    }

    suspend fun installRemote(context: Context, url: String, rootUri: Uri?, fileName: String, kind: String, curseForgeKey: String = ""): String {
        require(rootUri != null) { "Pilih folder Minecraft terlebih dahulu." }
        val root = DocumentFile.fromTreeUri(context, rootUri) ?: error("Folder tidak tersedia")
        return com.rlcjava.launcher.network.Http.openStream(url, mapOf("User-Agent" to "RLCJavaLauncher/0.2")).use { input ->
            when (kind) {
                "mod" -> { copyFile(context, input, root, "mods/$fileName"); "mods/$fileName" }
                "resourcepack" -> { copyFile(context, input, root, "resourcepacks/$fileName"); "resourcepacks/$fileName" }
                "shader" -> { copyFile(context, input, root, "shaderpacks/$fileName"); "shaderpacks/$fileName" }
                "world" -> { ZipInstaller.installWorldInput(context, input, fileName, root); "saves/${fileName.substringBeforeLast('.', fileName)}" }
                "modpack" -> { ZipInstaller.installInput(context, input, fileName, root, curseForgeKey); "modpack:$fileName" }
                else -> { copyFile(context, input, root, fileName); fileName }
            }
        }
    }

    internal fun copyFile(context: Context, input: java.io.InputStream, root: DocumentFile, relative: String) {
        val clean = relative.replace("\\", "/").trim('/')
        val parts = clean.split('/').filter { it.isNotBlank() && it != "." && it != ".." }
        require(parts.isNotEmpty()) { "Path kosong" }
        var dir = root
        for (part in parts.dropLast(1)) {
            dir = dir.findFile(part) ?: dir.createDirectory(part) ?: error("Tidak bisa membuat $part")
        }
        val target = dir.findFile(parts.last()) ?: dir.createFile("application/octet-stream", parts.last()) ?: error("Tidak bisa membuat file")
        context.contentResolver.openOutputStream(target.uri, "w")!!.use { out -> input.copyTo(out) }
    }

    suspend fun installDownloaded(context: Context, root: DocumentFile, url: String, path: String) {
        HttpDownload.copy(url, context, root, path)
    }
}
