package com.rlcjava.launcher.install

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import com.rlcjava.launcher.network.Http

object HttpDownload {
    suspend fun copy(url: String, context: Context, root: DocumentFile, relative: String) {
        Http.openStream(url, mapOf("User-Agent" to "RLCJavaLauncher/0.1")).use { input ->
            ContentInstaller.copyFile(context, input, root, relative)
        }
    }
}
