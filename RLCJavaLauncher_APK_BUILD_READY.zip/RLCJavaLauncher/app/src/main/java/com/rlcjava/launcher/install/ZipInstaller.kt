package com.rlcjava.launcher.install

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.google.gson.JsonParser
import com.rlcjava.launcher.network.CurseForgeClient
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

object ZipInstaller {
    suspend fun install(context: Context, source: Uri, root: DocumentFile, curseForgeKey: String) {
        context.contentResolver.openInputStream(source)?.use { input ->
            installInput(context, input, source.toString(), root, curseForgeKey)
        } ?: error("Tidak bisa membaca zip")
    }

    suspend fun installInput(context: Context, input: InputStream, archiveName: String, root: DocumentFile, curseForgeKey: String) {
        val entries = readEntries(input)
        val mrIndex = entries["modrinth.index.json"]
        val cfManifest = entries["manifest.json"]
        when {
            mrIndex != null -> installMrPack(context, root, entries, mrIndex)
            cfManifest != null -> installCursePack(context, root, entries, cfManifest, curseForgeKey)
            else -> {
                val normalized = entries.mapKeys { it.key.replace("\\", "/").trim('/') }
                val hasLevel = normalized.keys.any { it.substringAfterLast('/') == "level.dat" }
                val hasShadersDir = normalized.keys.any { it.startsWith("shaders/") }
                val hasPackMcmeta = normalized.keys.any { it.substringAfterLast('/') == "pack.mcmeta" }
                when {
                    hasLevel -> installWorldEntries(context, normalized, archiveName, root)
                    hasShadersDir -> installFlatPack(context, normalized, archiveName, root, "shaderpacks")
                    hasPackMcmeta && normalized.keys.any { it.startsWith("assets/") || it.startsWith("textures/") } -> installFlatPack(context, normalized, archiveName, root, "resourcepacks")
                    else -> normalized.forEach { (path, bytes) ->
                        val target = when {
                            path.startsWith("overrides/") -> path.removePrefix("overrides/")
                            path.startsWith("mods/") || path.startsWith("resourcepacks/") || path.startsWith("shaderpacks/") || path.startsWith("saves/") -> path
                            else -> null
                        }
                        if (target != null) ContentInstaller.copyFile(context, java.io.ByteArrayInputStream(bytes), root, target)
                    }
                }
            }
        }
    }

    suspend fun installWorldInput(context: Context, input: InputStream, archiveName: String, root: DocumentFile) {
        val entries = readEntries(input)
        installWorldEntries(context, entries.mapKeys { it.key.replace("\\", "/").trim('/') }, archiveName, root)
    }

    private fun installWorldEntries(context: Context, entries: Map<String, ByteArray>, archiveName: String, root: DocumentFile) {
        val normalized = entries.filterKeys { it.isNotBlank() && !it.endsWith("/") && !it.contains("../") }
        val topLevel = normalized.keys.mapNotNull { it.substringBefore('/').takeIf { x -> x.isNotBlank() } }.distinct()
        val folder = if (topLevel.size == 1) topLevel.first() else archiveName.substringBeforeLast('.')
        normalized.forEach { (path, bytes) ->
            val relative = if (topLevel.size == 1 && path.startsWith(folder + "/")) path.removePrefix(folder + "/") else path
            ContentInstaller.copyFile(context, java.io.ByteArrayInputStream(bytes), root, "saves/$folder/$relative")
        }
    }

    private fun installFlatPack(context: Context, entries: Map<String, ByteArray>, archiveName: String, root: DocumentFile, directory: String) {
        val folder = archiveName.substringBeforeLast('.')
        entries.forEach { (path, bytes) ->
            ContentInstaller.copyFile(context, java.io.ByteArrayInputStream(bytes), root, "$directory/$folder/$path")
        }
    }

    private fun readEntries(input: InputStream): LinkedHashMap<String, ByteArray> {
        val entries = LinkedHashMap<String, ByteArray>()
        ZipInputStream(input.buffered()).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                if (e.isDirectory) continue
                val path = e.name.replace("\\", "/")
                if (path.contains("../")) continue
                val out = ByteArrayOutputStream()
                zis.copyTo(out)
                entries[path] = out.toByteArray()
            }
        }
        return entries
    }

    private suspend fun installMrPack(context: Context, root: DocumentFile, entries: Map<String, ByteArray>, indexBytes: ByteArray) {
        val obj = JsonParser.parseString(indexBytes.toString(Charsets.UTF_8)).asJsonObject
        val files = obj.getAsJsonArray("files") ?: return
        for (f in files) {
            val o = f.asJsonObject
            val env = o.getAsJsonObject("env")
            val client = env?.get("client")?.asString ?: "required"
            if (client == "unsupported") continue
            val path = o.get("path").asString.replace("\\", "/")
            val bundled = entries[path]
            if (bundled != null) {
                ContentInstaller.copyFile(context, java.io.ByteArrayInputStream(bundled), root, path)
            } else {
                val downloads = o.getAsJsonArray("downloads") ?: continue
                val url = downloads.firstOrNull()?.asString ?: continue
                HttpDownload.copy(url, context, root, path)
            }
        }
        entries.forEach { (path, bytes) ->
            if (path.startsWith("overrides/")) ContentInstaller.copyFile(context, java.io.ByteArrayInputStream(bytes), root, path.removePrefix("overrides/"))
        }
    }

    private suspend fun installCursePack(context: Context, root: DocumentFile, entries: Map<String, ByteArray>, manifestBytes: ByteArray, apiKey: String) {
        require(apiKey.isNotBlank()) { "CurseForge modpack membutuhkan API key untuk mengambil file mod." }
        val obj = JsonParser.parseString(manifestBytes.toString(Charsets.UTF_8)).asJsonObject
        val files = obj.getAsJsonArray("files") ?: return
        val api = CurseForgeClient(apiKey)
        for (f in files) {
            val fo = f.asJsonObject
            val modId = fo.get("projectID").asInt
            val fileId = fo.get("fileID").asInt
            val url = runCatching { api.downloadUrl(modId, fileId) }.getOrNull()
            if (url != null) {
                val fileName = entries.keys.firstOrNull { it.endsWith("/$fileId.jar") }?.substringAfterLast('/') ?: "mod-$modId-$fileId.jar"
                HttpDownload.copy(url, context, root, "mods/$fileName")
            }
        }
        entries.forEach { (path, bytes) ->
            if (path.startsWith("overrides/")) ContentInstaller.copyFile(context, java.io.ByteArrayInputStream(bytes), root, path.removePrefix("overrides/"))
        }
    }
}
