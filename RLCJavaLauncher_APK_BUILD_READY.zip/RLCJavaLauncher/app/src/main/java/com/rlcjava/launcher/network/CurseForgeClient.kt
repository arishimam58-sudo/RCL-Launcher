package com.rlcjava.launcher.network

import com.google.gson.JsonParser

class CurseForgeClient(private val apiKey: String) {
    data class Mod(val id: Int, val name: String, val summary: String, val url: String?)
    data class FileInfo(val id: Int, val modId: Int, val fileName: String, val downloadUrl: String?)

    private val headers get() = mapOf("x-api-key" to apiKey, "Accept" to "application/json", "User-Agent" to "RLCJavaLauncher/0.1")

    suspend fun search(query: String, limit: Int = 20): List<Mod> {
        require(apiKey.isNotBlank()) { "Isi CurseForge API key di Settings." }
        require(query.isNotBlank()) { "Isi kata pencarian." }
        val q = java.net.URLEncoder.encode(query, Charsets.UTF_8)
        val text = Http.getText("https://api.curseforge.com/v1/mods/search?gameId=432&searchFilter=$q&pageSize=$limit", headers)
        val obj = JsonParser.parseString(text).asJsonObject
        return obj.getAsJsonArray("data").map { x ->
            val o = x.asJsonObject
            Mod(o.get("id").asInt, o.get("name").asString, o.get("summary")?.asString ?: "", o.getAsJsonObject("links")?.get("websiteUrl")?.asString)
        }
    }

    suspend fun latestFile(modId: Int, gameVersion: String, loaderType: Int?): FileInfo? {
        require(apiKey.isNotBlank()) { "Isi CurseForge API key di Settings." }
        val gv = java.net.URLEncoder.encode(gameVersion, Charsets.UTF_8)
        val loaderQuery = loaderType?.let { "&modLoaderType=$it" } ?: ""
        val text = Http.getText("https://api.curseforge.com/v1/mods/$modId/files?gameVersion=$gv$loaderQuery&pageSize=50", headers)
        val arr = JsonParser.parseString(text).asJsonObject.getAsJsonArray("data")
        val o = arr.firstOrNull()?.asJsonObject ?: return null
        val id = o.get("id").asInt
        val url = o.get("downloadUrl")?.takeUnless { it.isJsonNull }?.asString
        return FileInfo(id, modId, o.get("fileName").asString, url)
    }

    suspend fun downloadUrl(modId: Int, fileId: Int): String {
        val text = Http.getText("https://api.curseforge.com/v1/mods/$modId/files/$fileId/download-url", headers)
        return JsonParser.parseString(text).asJsonObject.get("data").asString
    }
}
