package com.rlcjava.launcher.network

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object Http {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    suspend fun getText(url: String, headers: Map<String, String> = emptyMap()): String =
        suspendCancellableCoroutine { cont ->
            val req = Request.Builder().url(url).apply {
                headers.forEach { (k, v) -> addHeader(k, v) }
            }.build()
            val call = client.newCall(req)
            cont.invokeOnCancellation { call.cancel() }
            call.enqueue(object : okhttp3.Callback {
                override fun onFailure(call: okhttp3.Call, e: IOException) {
                    if (cont.isActive) cont.resumeWithException(e)
                }

                override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                    response.use {
                        if (!it.isSuccessful) {
                            if (cont.isActive) cont.resumeWithException(IllegalStateException("HTTP ${it.code}"))
                            return
                        }
                        if (cont.isActive) cont.resume(it.body?.string().orEmpty())
                    }
                }
            })
        }

    suspend fun openStream(url: String, headers: Map<String, String> = emptyMap()): InputStream =
        suspendCancellableCoroutine { cont ->
            val req = Request.Builder().url(url).apply {
                headers.forEach { (k, v) -> addHeader(k, v) }
            }.build()
            val call = client.newCall(req)
            cont.invokeOnCancellation { call.cancel() }
            call.enqueue(object : okhttp3.Callback {
                override fun onFailure(call: okhttp3.Call, e: IOException) {
                    if (cont.isActive) cont.resumeWithException(e)
                }

                override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                    if (!response.isSuccessful) {
                        response.close()
                        if (cont.isActive) cont.resumeWithException(IllegalStateException("HTTP ${response.code}"))
                        return
                    }
                    val body = response.body
                    val stream = body?.byteStream()
                    if (stream == null) {
                        response.close()
                        if (cont.isActive) cont.resumeWithException(IllegalStateException("Empty response"))
                        return
                    }
                    // Caller closes the stream; Response is intentionally retained by OkHttp body.
                    if (cont.isActive) cont.resume(stream)
                }
            })
        }
}
