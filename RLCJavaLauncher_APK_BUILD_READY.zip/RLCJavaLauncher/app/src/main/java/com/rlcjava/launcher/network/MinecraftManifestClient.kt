package com.rlcjava.launcher.network

import com.google.gson.Gson

object MinecraftManifestClient {
    private const val URL = "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json"
    private val gson = Gson()
    data class Manifest(val versions: List<Version>)
    data class Version(val id: String, val type: String, val url: String, val time: String?, val releaseTime: String?)
    suspend fun fetch(): Manifest = gson.fromJson(Http.getText(URL, mapOf("User-Agent" to "RLCJavaLauncher/0.1")), Manifest::class.java)
}
