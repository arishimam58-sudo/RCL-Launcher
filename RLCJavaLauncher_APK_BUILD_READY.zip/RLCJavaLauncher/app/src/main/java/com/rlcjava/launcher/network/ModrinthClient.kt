package com.rlcjava.launcher.network

import com.google.gson.JsonParser

object ModrinthClient {
    data class Hit(val projectId: String, val slug: String, val title: String, val description: String, val downloads: Long, val iconUrl: String?, val projectType: String)
    data class FileInfo(val url: String, val fileName: String)

    suspend fun search(query: String, limit: Int = 20, projectType: String? = null, gameVersion: String? = null, loader: String? = null, category: String? = null, sort: String = "Relevance"): List<Hit> {
        require(query.isNotBlank()) { "Isi kata pencarian." }
        val q = java.net.URLEncoder.encode(query, Charsets.UTF_8)
        val facets = mutableListOf<String>()
        projectType?.takeIf { it.isNotBlank() && it != "world" }?.let { facets += "\"project_type:$it\"" }
        gameVersion?.takeIf { it.isNotBlank() }?.let { facets += "\"versions:$it\"" }
        loader?.takeIf { it.isNotBlank() && it != "all" }?.let { facets += "\"categories:$it\"" }
        category?.takeIf { it.isNotBlank() }?.let { facets += "\"categories:$it\"" }
        val facetQuery = if (facets.isEmpty()) "" else "&facets=" + java.net.URLEncoder.encode("[[${facets.joinToString(",")}]]", Charsets.UTF_8)
        val index = when (sort.lowercase()) {
            "downloads" -> "downloads"
            "updated" -> "updated"
            else -> "relevance"
        }
        val text = Http.getText("https://api.modrinth.com/v2/search?query=$q&limit=$limit&index=$index$facetQuery", mapOf("User-Agent" to "RLCJavaLauncher/0.2"))
        val obj = JsonParser.parseString(text).asJsonObject
        return obj.getAsJsonArray("hits").map { x ->
            val o = x.asJsonObject
            Hit(o.get("project_id").asString, o.get("slug").asString, o.get("title").asString,
                o.get("description")?.asString ?: "", o.get("downloads")?.asLong ?: 0,
                o.get("icon_url")?.takeUnless { it.isJsonNull }?.asString,
                o.get("project_type")?.asString ?: "unknown")
        }
    }

    suspend fun latestFile(projectId: String, gameVersion: String, loader: String): FileInfo? {
        val gv = java.net.URLEncoder.encode(gameVersion, Charsets.UTF_8)
        val ld = if (loader.isBlank()) "" else java.net.URLEncoder.encode(loader, Charsets.UTF_8)
        val loaderQuery = if (ld.isBlank()) "" else "&loaders=[$ld]"
        val text = Http.getText("https://api.modrinth.com/v2/project/$projectId/version?game_versions=[$gv]$loaderQuery&limit=20", mapOf("User-Agent" to "RLCJavaLauncher/0.1"))
        val arr = JsonParser.parseString(text).asJsonArray
        val version = arr.firstOrNull() ?: return null
        val files = version.asJsonObject.getAsJsonArray("files")
        val primary = files.firstOrNull { it.asJsonObject.get("primary")?.asBoolean == true } ?: files.firstOrNull() ?: return null
        val o = primary.asJsonObject
        return FileInfo(o.get("url").asString, o.get("filename").asString)
    }
}
