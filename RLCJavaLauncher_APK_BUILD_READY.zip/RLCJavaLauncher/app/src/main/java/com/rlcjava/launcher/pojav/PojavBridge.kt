package com.rlcjava.launcher.pojav

import android.content.Context

class PojavBridge(private val context: Context) {
    private val packages = listOf(
        "net.kdt.pojavlaunch.debug",
        "net.kdt.pojavlaunch"
    )

    fun isInstalled(): Boolean = packages.any { runCatching { context.packageManager.getPackageInfo(it, 0) }.isSuccess }

    fun launchPojav(): String {
        val pkg = packages.firstOrNull { runCatching { context.packageManager.getPackageInfo(it, 0) }.isSuccess }
            ?: return "PojavLauncher belum terpasang. Install APK Pojav terlebih dahulu."
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: return "Activity Pojav tidak ditemukan."
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "PojavLauncher dibuka."
    }
}
