# Integrasi final ke engine Java

Target desain final:

1. `Launcher UI` — Compose Material 3, navigasi Home / Instances / Mods / Worlds / Resource Packs / Shaders / Controls / Java / Settings.
2. `Engine Core` — source Pojav/Amethyst untuk bootstrap JVM, LWJGL, renderers, input, game process.
3. `Version Resolver` — metadata Mojang + dependency libraries/assets.
4. `Runtime Resolver` — Java 8 / 17 / 21 per versi Minecraft.
5. `Auth` — login Microsoft/Xbox/Minecraft dilakukan melalui modul autentikasi launcher core.
6. `Content` — Modrinth + CurseForge + local files; install ke instance, bukan satu folder global.
7. `Controls` — importer JSON/YAML/custom-control dan converter ke format kontrol engine.
8. `Instance` — setiap profile punya game directory sendiri agar mod, config, saves, shaders, resource packs terisolasi.
9. `Logs` — live log viewer + crash diagnostics.
10. `Backup` — export/import instance sebagai ZIP.

## Kenapa engine belum dibundel di source starter

File yang dikirim pengguna adalah APK. APK tersebut berisi bytecode dan native binaries, bukan source tree yang siap dikompilasi ulang. PojavLauncher sendiri sekarang sudah tidak dipelihara dan source lamanya menunjuk penerus Amethyst. Untuk integrasi yang bersih, source tree Pojav/Amethyst diperlukan.

## Artefak yang dibutuhkan untuk tahap berikutnya

- source ZIP Pojav/Amethyst (atau fork yang boleh dimodifikasi), dan
- file kontrol Zalith yang ingin dipertahankan.

Preferensi desain: jangan memakai nama/logo Zalith di aplikasi baru; gunakan branding RLC Java Launcher.
