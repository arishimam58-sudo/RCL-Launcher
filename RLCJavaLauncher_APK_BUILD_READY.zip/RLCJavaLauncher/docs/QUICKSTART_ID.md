# Cara cepat build di Android Studio

1. Extract ZIP.
2. Buka folder `RLCJavaLauncher` di Android Studio.
3. Pastikan JDK untuk Gradle adalah 17.
4. Tunggu Gradle Sync.
5. Sambungkan HP Android 13, aktifkan Developer Options + USB Debugging, lalu Run.
6. Install PojavLauncher dari APK yang kamu punya.
7. Buka RLC Java Launcher.
8. Pilih folder game Pojav melalui tombol `Pilih folder game Pojav`.
9. Untuk CurseForge, masukkan `x-api-key` di Settings.
10. Dari Mods/Tools gunakan Import untuk memasang file ke game directory.

Catatan: versi starter ini membuka engine Pojav dari tombol PLAY. Tahap integrasi source akan mengubahnya menjadi satu aplikasi dengan engine di dalam aplikasi.
