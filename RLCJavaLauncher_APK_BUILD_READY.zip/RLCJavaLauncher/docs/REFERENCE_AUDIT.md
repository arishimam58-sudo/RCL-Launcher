# UI Reference Audit — 22 screenshots

The supplied reference archive contained 22 landscape screenshots at 1612×720. The UI implementation maps the recurring patterns without copying the reference branding.

| Ref | Visual pattern observed | RLC implementation |
|---|---|---|
| 01 | launcher home + left actions + game card | `HomeScreen` + `MainRail` |
| 02–03 | video settings + translucent panels + switches | `SettingSection.VIDEO` |
| 04–05 | touch controls, sliders, virtual mouse | `SettingSection.CONTROLS` |
| 06–08 | version/runtime/game menu/FPS | `SettingSection.GAME` |
| 09–11 | download cache + personalization + launcher settings | `SettingSection.LAUNCHER` |
| 12 | experimental patches / external support | `SettingSection.EXPERIMENTAL` |
| 13–20 | content lists + right filter pane + provider branding | `ContentHubScreen` + `FilterPanel` |
| 17, 22 | shader result lists | `Download Shader Pack` page |
| 18–20 | Modrinth result list variations | `ModrinthClient` + async result cards |
| 21 | unsupported resource/category state | empty/result-state card |

## Recurring visual rules extracted from the references

- Landscape-first launcher composition with a narrow vertical rail.
- Large scenic background with a dark translucent scrim.
- Semi-transparent rounded cards with thin low-contrast borders.
- Compact white labels, muted secondary text, and bright aqua/purple accents.
- Header actions at the top right: import/download/home/folder.
- Content pages use a two-column layout: scrollable results on the left and filters on the right.
- Settings use stacked cards with toggles, sliders, and short explanations.

## Functional mapping

- Mod search: Modrinth API v2.
- CurseForge search: official v1 REST API with user-supplied API key.
- Minecraft version manifest: Mojang `version_manifest_v2.json`.
- Local import: `.jar`, `.mrpack`, `.zip`, JSON/YAML/control profile.
- Remote install targets: `mods/`, `resourcepacks/`, `shaderpacks/`, and `saves/`.
- Modpack import: Modrinth `.mrpack` and CurseForge `manifest.json` flows.
- Pojav integration: detects and opens the installed Pojav package.
