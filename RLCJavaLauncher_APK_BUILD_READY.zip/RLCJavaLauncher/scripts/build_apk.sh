#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! command -v java >/dev/null 2>&1; then
  echo "Java belum terpasang. Di Termux: pkg install openjdk-21"
  exit 1
fi

if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "ANDROID_HOME/ANDROID_SDK_ROOT belum di-set."
  echo "Pasang Android SDK (mis. AndroidIDE/SDK), lalu set environment variable-nya."
  exit 2
fi

if [[ -x "./gradlew" ]]; then
  ./gradlew --no-daemon :app:assembleDebug
elif command -v gradle >/dev/null 2>&1; then
  gradle --no-daemon :app:assembleDebug
else
  echo "Gradle belum terpasang. Pasang Gradle 8.9+ atau gunakan GitHub Actions." 
  exit 3
fi

echo
printf 'APK: %s\n' "$ROOT/app/build/outputs/apk/debug/app-debug.apk"
